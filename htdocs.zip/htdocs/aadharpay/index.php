<?php

$str = file_get_contents('https://www.freecharge.in/rds/plans/652/14/7410743968');

$trimmed = str_replace("\\n", "", $str);

$json = json_decode($trimmed, true); 

// echo '<pre>' . print_r($json['data']['categoryDetails'], true) . '</pre>';
// echo '<pre>' . print_r($json['data']['planDetails'], true) . '</pre>';

echo '<pre>';
echo '[';
for($i=0;$i<count($json['data']['categoryDetails']);$i++){
echo '{ "type": "'.$json['data']['categoryDetails'][$i]['category'].'",';
    echo  '"data": [';
        for($j=0;$j<count($json['data']['categoryDetails'][$i]['planIds']);$j++){
            echo  '{';
            $id = $json['data']['categoryDetails'][$i]['planIds'][$j];
            echo '"rs":'.$json['data']['planDetails'][$id]['amount'].',';
            echo '"decs": "'.$json['data']['planDetails'][$id]['description'].'"';
            if(count($json['data']['planDetails'][$id]['attributes'])!=0){
                echo  ',';
            }
            for($a=0;$a<count($json['data']['planDetails'][$id]['attributes']);$a++){
                if($json['data']['planDetails'][$id]['attributes'][$a]['tag']=="Validity"){
                    $json['data']['planDetails'][$id]['attributes'][$a]['tag']=="val";
                }
                if($json['data']['planDetails'][$id]['attributes'][$a]['tag']=="Validity"){
                    $json['data']['planDetails'][$id]['attributes'][$a]['tag']=="data";
                }
                echo '"'.$json['data']['planDetails'][$id]['attributes'][$a]['tag'].'":"'.$json['data']['planDetails'][$id]['attributes'][$a]['value'].'"';
                if($a<count($json['data']['planDetails'][$id]['attributes'])-1){
                    echo ',';
                }
            }
            echo  '}';
            if($j<count($json['data']['categoryDetails'][$i]['planIds'])-1){
                echo  ',';
            }
        } 
        echo ']';
        echo  '}';
        if($i<count($json['data']['categoryDetails'])-1){
            echo  ',';
        }
}
echo ']';
echo '</pre>';

?>