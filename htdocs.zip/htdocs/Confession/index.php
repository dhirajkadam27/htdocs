<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="./header.css"> 
           <link rel="stylesheet" href="./slider.css">
           <link rel="stylesheet" href="./body.css">
<style>
body{
    margin:0;
    padding:0;
    background:#FAFAFA;
    font-family: monospace;
}
@media only screen and (max-width: 768px) {
    .main {
    width: 100%;
    display: block;
    }
}

@media only screen and (min-width: 768px) {

.main {
    display: flex;
    justify-content: center;
    padding-top:20px
}
}
</style>
</head>
<body>
<div class="layout">
    <?php include 'header.php';?>
    <div class="main">
        <?php include 'slider.php';?>
        <?php include 'body.php';?>
    </div>
</div>
</div>
</body>
</html>