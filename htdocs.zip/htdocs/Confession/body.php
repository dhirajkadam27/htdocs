<div class="body">
    <div class="add">
        <div class="add_txt">Add your confession_</div>
        <div class="postbtn">Post_</div>
    </div>
    <div class="box">
        <div class="to">
            <div class="box_txt">To_: </div>
            <div class="box_to"><a href="./">Dhiraj Kadam</a></div>
        </div>
        <div class="from">
            <div class="box_txt">From_: </div>
            <div class="box_from">CSE S.Y</div>
        </div>
        <div class="from">
            <div class="box_txt">Date_: </div>
            <div class="box_from">Aug,21 2022</div>
        </div>
        <div class="confess">
            <div class="box_txt">Confession_: </div>
            <div class="box_Confession">But the main principle remains the same and besides that, we don’t have all day, and that hand you’re keeping up is probably hurting a lot by now_.</div>
        </div>
        <div class="to">
        <div class="like">Like_</div>
        <div class="like">Share_</div>
        </div>
    </div>

    <div class="box">
        <div class="to">
            <div class="box_txt">To_: </div>
            <div class="box_to"><a href="./">Dhiraj Kadam</a></div>
        </div>
        <div class="from">
            <div class="box_txt">From_: </div>
            <div class="box_from">CSE S.Y</div>
        </div>
        <div class="from">
            <div class="box_txt">Date_: </div>
            <div class="box_from">Aug,21 2022</div>
        </div>
        <div class="confess">
            <div class="box_txt">Confession_: </div>
            <div class="box_Confession">But the main principle remains the same and besides that, we don’t have all day, and that hand you’re keeping up is probably hurting a lot by now_.</div>
        </div>
        <div class="to">
        <div class="like">Like_</div>
        <div class="like">Share_</div>
        </div>
    </div>

    <div class="box">
        <div class="to">
            <div class="box_txt">To_: </div>
            <div class="box_to"><a href="./">Dhiraj Kadam</a></div>
        </div>
        <div class="from">
            <div class="box_txt">From_: </div>
            <div class="box_from">CSE S.Y</div>
        </div>
        <div class="from">
            <div class="box_txt">Date_: </div>
            <div class="box_from">Aug,21 2022</div>
        </div>
        <div class="confess">
            <div class="box_txt">Confession_: </div>
            <div class="box_Confession">But the main principle remains the same and besides that, we don’t have all day, and that hand you’re keeping up is probably hurting a lot by now_.</div>
        </div>
        <div class="to">
        <div class="like">Like_</div>
        <div class="like">Share_</div>
        </div>
    </div>
 
    

</div>