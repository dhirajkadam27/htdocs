<div class="slider">
    <div class="input">
        <img onclick="openNav()" src="./menu.png">
        <input type="text" placeholder="search student profiles">
    </div>
    <div class="slider_app">Applications</div>
    <div class="slider_links">
        <div class="link"><a href="./">Home_</a></div>
        <div class="link"><a href="./">Confess_</a></div>
        <div class="link"><a href="./">Top Confessions_</a></div>
        <div class="link"><a href="./">Popular Profiles_</a></div>
        <div class="link"><a href="./">About Us_</a></div>
    </div>
</div>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <div class="slider_links_2">
        <div class="link_2"><a href="./">Home_</a></div>
        <div class="link_2"><a href="./">Confess_</a></div>
        <div class="link_2"><a href="./">Top Confessions_</a></div>
        <div class="link_2"><a href="./">Popular Profiles_</a></div>
        <div class="link_2"><a href="./">About Us_</a></div>
    </div>
</div>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>