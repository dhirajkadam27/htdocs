<?php
require 'config_facemash.php';

$id_1 = $_GET['id_1'];
$id_2 = $_GET['id_2'];
$selected_id = $_GET['selected_id'];

$id = 0;
$img = 0;
$name = 0;
$current_rating=0;


$sql= "SELECT * FROM `records` WHERE id='$id_1'";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
    if($selected_id==$id_1){
        $sql = "UPDATE `records` SET visited='".($check['visited']+1)."' ,  selected='".($check['selected']+1)."',  rate='".((($check['selected']+1)/($check['visited']+1))*10)."' WHERE id='$id_1'";
        $current_rating = ((($check['selected']+1)/($check['visited']+1))*10);
    }else{
        $sql = "UPDATE `records` SET visited='".($check['visited']+1)."' ,  selected='".($check['selected'])."',  rate='".((($check['selected'])/($check['visited']+1))*10)."' WHERE id='$id_1'";
    }

    if ($conn->query($sql) === TRUE) {
    // echo "Record updated successfully";
    } else {
    echo "Error updating record: " . $conn->error;
    }
}else{

}


$sql= "SELECT * FROM `records` WHERE id='$id_2'";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
    if($selected_id==$id_2){
        $sql = "UPDATE `records` SET visited='".($check['visited']+1)."' ,  selected='".($check['selected']+1)."',  rate='".((($check['selected']+1)/($check['visited']+1))*10)."' WHERE id='$id_2'";
        $current_rating = ((($check['selected']+1)/($check['visited']+1))*10);
    }else{
        $sql = "UPDATE `records` SET visited='".($check['visited']+1)."' ,  selected='".($check['selected'])."',  rate='".((($check['selected'])/($check['visited']+1))*10)."' WHERE id='$id_2'";
    }

    if ($conn->query($sql) === TRUE) {
    // echo "Record updated successfully";
    } else {
    echo "Error updating record: " . $conn->error;
    }
}else{
    
}

$sql= "SELECT * FROM `records` WHERE id!=$id_1 AND id!=$id_2 AND rate >$current_rating ORDER BY rate DESC LIMIT 1";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
    $id = $check['id'];
    $img = $check['img'];
    $name = $check['name'];
}else{
    
    $sql= "SELECT * FROM `records` WHERE id!=$id_1 AND id!=$id_2 AND rate <$current_rating ORDER BY rate DESC LIMIT 1";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
    $id = $check['id'];
    $img = $check['img'];
    $name = $check['name'];
}else{
    
}

}


$conn->close();
echo '{"id":"'.$id.'","img":"'.$img.'","name":"'.$name.'"}';
?>