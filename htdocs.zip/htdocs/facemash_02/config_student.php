<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "students_record";

// Create connection
$conn_1 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn_1->connect_error)
{
    die("Connection failed: " . $conn_1->connect_error);
}

?>
