<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
        <style>
            body{
                margin: 0;
    padding: 0;
    background-color: #000715;
    font-family: 'Urbanist', sans-serif;
    color: white;
            }
        .title{
            font-size: 50px;
            font-weight: 900;
            display: block;
            text-align: center;
            margin-top: 67px;
            color: #b9f5ff;
        }
.tag {
    font-size: 25px;
    font-weight: 400;
    display: block;
    text-align: center;
    color: #c8dbff;
    margin-top: 10px;
    margin-bottom: 40px;
}
.msg {
    font-size: 25px;
    font-weight: bold;
    display: block;
    text-align: center;
    color: #c8ffc8;
    margin-top: 10px;
    margin-bottom: 40px;
}
    </style>
    </head>
    <body>
        <div class="title">VisionX</div>
        <div class="tag">It all start's with a dream</div>
          
        <?php
require 'config_facemash.php';
$name = $_GET['name'];
$mobile = $_GET['mobile'];
$email = $_GET['email'];
$expertise = $_GET['expertise'];
$branch = $_GET['branch'];
$division = $_GET['division'];
$sql = "INSERT INTO `members`( `name`, `mobile`, `email`, `expertise`, `branch`, `division`) VALUES ('$name','$mobile','$email','$expertise','$branch','$division')";

if ($conn->query($sql) === TRUE) {
  echo '<div class="msg">Form Submitted Successfully</div>';
} else {
    echo '<div class="msg">Unable To Submitted Form</div>';
}

$conn->close();

?>
    </body>
</html>