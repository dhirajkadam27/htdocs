<?php
require 'config_facemash.php';


  $sql = "SELECT * FROM `records` ORDER BY visited ASC";
    $result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

    //create an array
    $emparray = array();
    while($row =mysqli_fetch_assoc($result))
    {
            $emparray[] = $row;
    // echo json_encode(array_reverse($emparray));
    }
    
    
    $sql1 = "SELECT * FROM `visitor`";
    $result = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));

    while($row1 =mysqli_fetch_assoc($result))
    {
             
                       $sql2 = "UPDATE `visitor` SET `visitor`='".($row1['visitor']+1)."'";
        
            if ($conn->query($sql2) === TRUE) {
            //   echo "Record updated successfully";
            } else {
            //   echo "Error updating record: " . $conn1->error;
            }
    }
    
    echo '<script>
    const array = '.json_encode($emparray).';
    let length = '.count($emparray).';
    console.log(array);
    console.log(length-1);
    </script>';
    ?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.3.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/4.1.3/darkly/bootstrap.min.css">
        <style>
            body{
                margin: 0;
                padding: 0;
                background-color: #FFF7FD;
                font-family: 'Urbanist', sans-serif;
            }
            .nav {
    width: 96%;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: left;
    padding: 10px 2%;
}
.nav img {
    width: 200px;
}
.txt{
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 25px;
    font-weight: bold;
    color: #FF004C;
}
.txt_2 {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 45px;
    font-weight: bold;
    color: #3d3d3d;
    margin-top: 50px;
    margin-bottom: -25px;
}
.txt img{
    width: 30px;
    margin-bottom: 20px;
}
.imgs {
    display: flex;
    align-items: center;
    justify-content: space-evenly;
    width: 100%;
    margin-bottom:60px ;
}
.name {
    padding: 10px;
    font-size: 15px;
    font-weight: 700;
    color: #8615f8;
}
.box {
    width: 20%;
    max-width: 200px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0px 0px 20px 10px #ffb7cd;
  position: relative;
}
.box img {
    width: 100%;
    height: 200px;
}
.data{
    width: 100%;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.rank{
    width: 30%;
    display: block;
    text-align: left;
    font-size: 20px;
    font-weight: 900;
    color: #353535;
}
.vote{
    width: 30%;
    display: block;
    text-align: left;
    font-size: 20px;
    font-weight: 900;
    color: #353535;
}
.rank_1{
    width: 30%;
    display: block;
    text-align: left;
    font-size: 20px;
    font-weight: 600;
    color: #8f00cf;
}
.vote_1{
    width: 30%;
    display: block;
    text-align: left;
    font-size: 20px;
    font-weight: 600;
    color: #8f00cf;
}


canvas#confetti-canvas {
    width: 100%;
    height: 100vh;
    position: absolute;
    z-index: 10;
    top: 0;
    left: 0;
}
      
      
   
.winner {
    width: 100%;
    height: 100vh;
    display: none;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    background: #ffc0cb38;
    z-index: 9;
}

.win {
    width: 20%;
    max-width: 200px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0px 0px 20px 10px #ffb7cd;
  position: relative;
}
.win img {
    width: 100%;
    height: 200px;
}
.name_1{
    padding: 0 10px;
    font-size: 20px;
    font-weight: 700;
    color: #FF004C;
}
#heart{
    width: 25px;
    height: 25px;
    margin-bottom: 25px;
}

@media only screen and (max-width: 700px) {
               /* For mobile phones: */
               .txt_2{
                margin-top: 5px;
    margin-bottom: 10px;
               }
               .box{
                width: 40%;
  position: relative;
               }
               .box img{
                height: 150px;
               }
               .rank{
                width: 48%;
    padding-left: 2%;
               }
               .vote{
                width: 48%;
    padding-left: 2%;
               }
               .rank_1{
                width: 48%;
    padding-left: 2%;
               }
               .vote_1{
                width: 48%;
    padding-left: 2%;
               }
               
               .win{
                width: 40%;
  position: relative;
               }

            }
.instagram-heart {   
  width: 90%;
  height: 162px;
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  margin: auto;
  background: url("https://imgur.com/rksyGE8.png") no-repeat center/contain;
  opacity: 0;
  transform: scale(0);
}

@keyframes like-heart-animation{ 
  0% { opacity:0; transform:scale(0); }
  15% { opacity:.9; transform:scale(1.2); }
  30% { transform:scale(.95); }
  45%,
  80% { opacity:.9; transform:scale(1); }
}

.visionx{
    font-size: 50px;
    font-weight: 900;
    display: block;
    text-align: center;
    color: #00143a;
    margin-top: 67px;
}
.tag {
    font-size: 29px;
    font-weight: 400;
    display: block;
    text-align: center;
    color: #00143a;
}
.btn{
    background: black;
    font-size: 20px;
    font-weight: bold;
    padding: 10px 25px;
    display: block;
}
.button{
    display: flex;
    justify-content: center;
    margin-top: 20px;
    margin-bottom: 100px;
}

</style>
    </head>
    <body>
        <div class="nav">
            <img src="./logo.svg" alt="logo">
        </div>
        <div class="txt">Let's find the popular<br> girl in college!<img src="./heart.svg" alt="heart"></div>
        <div class="txt_2">or</div>
        <div class="imgs">
            <div onclick="box_1()" class="box">
              <div id="instagram-heart_1" class="instagram-heart">
              </div>
                <img id="img_1" src="data:image/jpg;charset=utf8;base64,<?php echo $emparray[0]['img'];?>" alt="<?php echo $emparray[0]['id'];?>">
                <div id="name_1" class="name"><?php echo $emparray[0]['name'];?></div>
            </div>
            <div onclick="box_2()" class="box">
            <img id="guide" src="https://media2.giphy.com/media/71QSOB7jUhDIxKEzGU/giphy.gif">
              <div id="instagram-heart_2" class="instagram-heart">
              </div>
                <img id="img_2" src="data:image/jpg;charset=utf8;base64,<?php echo $emparray[1]['img'];?>" alt="<?php echo $emparray[1]['id'];?>">
                <div id="name_2" class="name"><?php echo $emparray[1]['name'];?></div>
            </div>
        </div>

        <div class="data">
            <div class="rank">Ranker's</div>
            <div class="Vote">Rating</div>
        </div>

        <?php
        $sql = "SELECT * FROM `records` ORDER BY rate DESC LIMIT 3";
    $result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));


    while($row =mysqli_fetch_assoc($result))
    {
            echo '<div class="data">
            <div class="rank_1"><img style="width: 40px;border-radius: 100px;margin-right:10" id="profile" src="data:image/jpg;charset=utf8;base64,'.$row['img'].'">'.$row['name'].'</div>
            <div class="Vote_1">'.$row['rate'].'</div>
        </div>';
    // echo json_encode(array_reverse($emparray));
    }
?>
        


    <script src="confetti.js"></script>
    <div class="winner">
    <div class="win">
                <img id="img_3" src="data:image/jpg;charset=utf8;base64,<?php echo $emparray[1]['img'];?>" alt="<?php echo $emparray[1]['id'];?>">
                <div id="name_3" class="name_1"><?php echo $emparray[1]['name'];?></div>
                <div class="name_1">Winner!<img id="heart" src="./heart.svg" alt="heart"></div>
            </div>
    </div>


    <div class="visionx">VisionX</div>
    <div class="tag">It all start's with a dream</div>
    <div class="button">
    <div onclick="window.location.href='visionx.html'" class="btn">join our community</div>
</div>
<script>
let initial_value=2;
let off = 0;

setTimeout(function () {
      $('#guide').css( "display", "none");
     }, 3000);

document.addEventListener("keydown", function(event) {
         if (event.key == "ArrowLeft"){
            if(off==0){
                box_1();
            }
         }else if (event.key == "ArrowRight"){
            if(off==0){
                box_2();
            }
         }
      });
    
function box_1() {
        if(initial_value==(length-1)){
            var img = $('#img_1').attr('src');
            var names = document.getElementById('name_1').innerText;
            
    $('#img_3').attr("src",img);
    $('#name_3').text(names);
      $('.winner').css( "display", "flex");
            startConfetti();
            off=1;
              }else{
                $('#img_2').attr("src","https://media2.giphy.com/media/3oEjI6SIIHBdRxXI40/200w.gif?cid=6c09b952n8zsce7svgumpllvyt0mhdv823qa2ujtf1q2h53p&rid=200w.gif&ct=g");
     $('#instagram-heart_1').css( "animation-duration", "1000ms" );
     $('#instagram-heart_1').css( "animation-name", "like-heart-animation" );
     $('#instagram-heart_1').css( "animation-timing-function", "ease-in-out" );
     setTimeout(function () {
     $('#instagram-heart_1').css( "animation-duration", "" );
     $('#instagram-heart_1').css( "animation-name", "" );
     $('#instagram-heart_1').css( "animation-timing-function", "" );
     }, 1000);


     let fetchRes = fetch(
    "/facemash_initial_api.php?id_1="+$('#img_1').attr('alt')+"&id_2="+$('#img_2').attr('alt')+"&selected_id="+$('#img_1').attr('alt'));
    // fetchRes is the promise to resolve
    // it by using.then() method
    fetchRes.then(res =>
        res.json()).then(d => {
    $('#img_2').attr("alt",array[initial_value]['id']);
    $('#img_2').attr("data",initial_value);
    $('#img_2').attr("src","data:image/jpg;charset=utf8;base64,"+array[initial_value]['img']);
    $('#name_2').text(array[initial_value]['name']);
            console.log(initial_value);
        
        initial_value++;
        });
              }
   };
    
  function box_2() {
        if(initial_value==(length-1)){
            var img = $('#img_2').attr('src');
            var names = document.getElementById('name_2').innerText;
            
    $('#img_3').attr("src",img);
    $('#name_3').text(names);
      $('.winner').css( "display", "flex");
      startConfetti();
            off=1;
        }else{
            $('#img_1').attr("src","https://media2.giphy.com/media/3oEjI6SIIHBdRxXI40/200w.gif?cid=6c09b952n8zsce7svgumpllvyt0mhdv823qa2ujtf1q2h53p&rid=200w.gif&ct=g");
   $('#instagram-heart_2').css( "animation-duration", "1000ms" );
   $('#instagram-heart_2').css( "animation-name", "like-heart-animation" );
   $('#instagram-heart_2').css( "animation-timing-function", "ease-in-out" );
   setTimeout(function () {
   $('#instagram-heart_2').css( "animation-duration", "" );
   $('#instagram-heart_2').css( "animation-name", "" );
   $('#instagram-heart_2').css( "animation-timing-function", "" );
   }, 1000);

   
   let fetchRes = fetch(
    "/facemash_initial_api.php?id_1="+$('#img_1').attr('alt')+"&id_2="+$('#img_2').attr('alt')+"&selected_id="+$('#img_2').attr('alt'));
    // fetchRes is the promise to resolve
    // it by using.then() method
    fetchRes.then(res =>
        res.json()).then(d => {
    $('#img_1').attr("alt",array[initial_value]['id']);
    $('#img_1').attr("data",initial_value);
    $('#img_1').attr("src","data:image/jpg;charset=utf8;base64,"+array[initial_value]['img']);
    $('#name_1').text(array[initial_value]['name']);
            console.log(initial_value);
        
        initial_value++;
        });
        }
   
 };

</script>
    </body>
</html>