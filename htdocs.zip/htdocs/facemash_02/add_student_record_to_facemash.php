<?php
require 'config_student.php';
require 'config_facemash.php';


  $sql = "SELECT * FROM `s.y`";
    $result = mysqli_query($conn_1, $sql) or die("Error in Selecting " . mysqli_error($conn_1));
$i=0;
    while($row =mysqli_fetch_assoc($result))
    {
      if($row['gender']==0&&$row['Seat']!=0){
      
        $sql = "INSERT INTO `facemash`(`name`, `img`, `visited`, `selected`,`rate`) VALUES ('".$row['First']."','".$row['img']."','0','0','0')";
 
         if ($conn->query($sql) === TRUE) {
           echo "New record created successfully";
           echo '<img src="'.$row['img'].'">';
         } else {
           echo "Error: " . $sql . "<br>" . $conn->error;
         }
      }
    }
    $conn->close();
    
    //close the db connection
    mysqli_close($conn_1);

?>