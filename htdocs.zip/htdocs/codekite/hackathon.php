<html>
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <style>
            body{
                margin: 0;
                padding: 0;
                font-family: 'Open Sans', sans-serif;
                background: #f0f5f5;
            }
            <?php
            require './css/header.css';
            require './css/footer.css';
            ?>
            
.topbar {
    width: 100%;
    align-items: center;
    justify-content: center;
    display: flex;
    margin-top: 40px;
    margin-bottom: 30px;
}
.srcbar{
    display: flex;
    align-items: center;
    width: 50%;
}
.srcbar input{
    width: 80%;
    height: 45px;
    border: 1px solid #D2D2D2;
    padding: 0 15px;
    color: white;
    border-radius:5px 0 0 5px;
    font-family: 'Open Sans', sans-serif;
}
.srcbtn{
    padding: 0 25px;
    height: 45px;
    border: none;
    background: #6C9BE3;
    font-size: 13px;
    font-weight: 600;
    color: white;
    border-radius:0 5px 5px 0;
    
    font-family: 'Open Sans', sans-serif;
}
.myhackathon button{
    padding: 0 25px;
    height: 45px;
    border: none;
    background: #FFB11A;
    font-size: 13px;
    font-weight: 600;
    color: black;
    border-radius: 5px;
                font-family: 'Open Sans', sans-serif;
}


.title{
    font-size: 20px;
    font-weight: 700;
    color: #232323;
    padding-left: 40px;
    padding-bottom: 30px;
}
.hackathon_layout{
    display: flex;
    padding-bottom: 30px;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}
.hackathon_container{
    width: 500px;
    border-radius: 15px;
    background: white;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    margin: 20px 20px;
}




.f_line{
    display: flex;
    justify-content: space-between;
    padding: 10px 20px;
    margin-top: 10px;
}
.name{
    font-size: 20px;
    font-weight: 800;
}
.day{
    padding: 7px 20px;
    background: #6C9BE3;
    border-radius: 100px;
    color: white;
    font-size: 12px;
    font-weight: 600;
}
.theme {
    padding-left: 20px;
    font-size: 15px;
    font-weight: 500;
    color: #959595;
    padding-bottom: 6px;
}
.s_line {
    display: flex;
    align-items: center;
    padding: 10px 20px;
}
.theme_box {
    padding: 5px 20px;
    border: 1px solid #E1E1E1;
    border-radius: 100px;
    color: #686868;
    font-weight: 600;
    margin-right: 10px;
}
.t_line {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}
.members {
    display: flex;
    align-items: center;
}
.profile {
    width: 35px;
    height: 35px;
    background: #bcbcbc;
    border-radius: 100px;
    border: 3px solid white;
    margin-left: -15px;
}
.profile:nth-child(1) {
    margin-left: 0;
}
.participants {
    margin-left: 5px;
    font-size: 15px;
    font-weight: bold;
    color: #287DAD;
}
.social_links {
    display: flex;
    align-items: center;
}
.web_link {
    width: 35px;
    height: 35px;
    background: #D4E0FF;
    border-radius: 100px;
    margin-left: 5px;
}
.fo_line {
    display: flex;
    align-items: center;
    padding: 10px 20px;
    justify-content: space-between;
    margin-bottom: 10px;
}
.highlight {
    display: flex;
    align-items: center;
}
.tag {
    padding: 5px 15px;
    background: #d0d0d0;
    border-radius: 10px;
    margin-right: 10px;
    font-size: 13px;
    font-weight: 600;
    color: #1e1e1e;
}
.apply button {
    border: none;
    background: #FFB11A;
    padding: 10px 20px;
    font-size: 12px;
    font-weight: 700;
    border-radius: 10px;
                font-family: 'Open Sans', sans-serif;
}

        </style>
    </head>
    <body>
            <?php
            require './elements/header.php';
            ?>


<div class="main">

<div class="topbar">
    <div class="srcbar">
        <input type="text" placeholder="Search by username or hackathon" class="srcinput">
        <button class="srcbtn">Search</button>
    </div>
    <div class="myhackathon"><button>My Hackathon</button></div>
</div>


<div class="title">Open</div>


<div class="hackathon_layout">
    <div class="hackathon_container">
        <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
        <div class="theme">Theme</div>
        <div class="s_line"><div class="theme_box">AI/ML</div></div>
        <div class="t_line">
            <div class="members">
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="participants">+500 participants</div>
            </div>
            <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
        </div>
        <div class="fo_line">
            <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
            <div class="apply"><button>Apply Now</button></div>
        </div>
    </div>
    <div class="hackathon_container">
        <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
        <div class="theme">Theme</div>
        <div class="s_line"><div class="theme_box">AI/ML</div></div>
        <div class="t_line">
            <div class="members">
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="participants">+500 participants</div>
            </div>
            <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
        </div>
        <div class="fo_line">
            <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
            <div class="apply"><button>Apply Now</button></div>
        </div>
    </div>
    <div class="hackathon_container">
        <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
        <div class="theme">Theme</div>
        <div class="s_line"><div class="theme_box">AI/ML</div></div>
        <div class="t_line">
            <div class="members">
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="profile"></div>
                <div class="participants">+500 participants</div>
            </div>
            <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
        </div>
        <div class="fo_line">
            <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
            <div class="apply"><button>Apply Now</button></div>
        </div>
    </div>
   
</div>




        </div>

            <?php
            require './elements/footer.php';
            ?>
    </body>
</html>