<html>
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <style>
            body{
                margin: 0;
                padding: 0;
                font-family: 'Open Sans', sans-serif;
                background: #f0f5f5;
            }
            <?php
            require './css/header.css';
            require './css/footer.css';
            ?>

            
.main{
    width: 100%;
    position: relative;
    overflow: hidden;
}
.map_bg{
    width: 70%;
    margin-top: 50px;
    position: absolute;
    z-index: -1;
    left: 15%;
}
.map_bg img{
    width: 100%;
}
.tagline {
    font-size: 50px;
    font-weight: 900;
    width: 650px;
    text-align: center;
    margin: 0 auto;
    margin-top: 150px;
}
.sub_title {
    width: 60%;
    text-align: center;
    margin: 0 auto;
    color: #565656;
    margin-top: 10px;
    font-weight: 500;
}
.join {
    border: none;
    background: #1357BD;
    color: white;
    padding: 15px;
    font-size: 14px;
    font-weight: 600;
    width: 150px;
    margin: 10px auto;
    display: block;
    margin-top: 60px;
}
.analytics{
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    margin-top: 150px;
    margin-bottom: 100px;
}
.analytics_content{
    width: 20%;
}
.analytics_no{
    font-size: 40px;
    font-weight: 900;
    color: #FF903F;
}
.analytics_txt{
    font-size: 15px;
    font-weight: 600;
    color: #585858;
    margin-top: 10px;
}

.title{
    font-size: 20px;
    font-weight: 700;
    color: #232323;
    padding-left: 40px;
    padding-bottom: 30px;
}
.hackathon_layout{
    display: flex;
    padding-bottom: 30px;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}
.hackathon_container{
    width: 500px;
    border-radius: 15px;
    background: white;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    margin: 20px 20px;
}




.f_line{
    display: flex;
    justify-content: space-between;
    padding: 10px 20px;
    margin-top: 10px;
}
.name{
    font-size: 20px;
    font-weight: 800;
}
.day{
    padding: 7px 20px;
    background: #6C9BE3;
    border-radius: 100px;
    color: white;
    font-size: 12px;
    font-weight: 600;
}
.theme {
    padding-left: 20px;
    font-size: 15px;
    font-weight: 500;
    color: #959595;
    padding-bottom: 6px;
}
.s_line {
    display: flex;
    align-items: center;
    padding: 10px 20px;
}
.theme_box {
    padding: 5px 20px;
    border: 1px solid #E1E1E1;
    border-radius: 100px;
    color: #686868;
    font-weight: 600;
    margin-right: 10px;
}
.t_line {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}
.members {
    display: flex;
    align-items: center;
}
.profile {
    width: 35px;
    height: 35px;
    background: #bcbcbc;
    border-radius: 100px;
    border: 3px solid white;
    margin-left: -15px;
}
.profile:nth-child(1) {
    margin-left: 0;
}
.participants {
    margin-left: 5px;
    font-size: 15px;
    font-weight: bold;
    color: #287DAD;
}
.social_links {
    display: flex;
    align-items: center;
}
.web_link {
    width: 35px;
    height: 35px;
    background: #D4E0FF;
    border-radius: 100px;
    margin-left: 5px;
}
.fo_line {
    display: flex;
    align-items: center;
    padding: 10px 20px;
    justify-content: space-between;
    margin-bottom: 10px;
}
.highlight {
    display: flex;
    align-items: center;
}
.tag {
    padding: 5px 15px;
    background: #d0d0d0;
    border-radius: 10px;
    margin-right: 10px;
    font-size: 13px;
    font-weight: 600;
    color: #1e1e1e;
}
.apply button {
    border: none;
    background: #FFB11A;
    padding: 10px 20px;
    font-size: 12px;
    font-weight: 700;
    border-radius: 10px;
                font-family: 'Open Sans', sans-serif;
}


.project_layout{
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-top: 120px;
}
.project_layout_left{
    width: 30%;
}
.project_txt{
    font-size: 40px;
    font-weight: 900;
    color: #1d1d1d;
}
.project_layout_left button{
    padding: 10px 25px;
    border: none;
    background: #FFB11A;
    border-radius: 7px;
    font-weight: 700;
    font-size: 13px;
    margin-top: 20px;
                font-family: 'Open Sans', sans-serif;
}
.project_container{
    width: 300px;
    background: white;
    border-radius: 10px;
    padding: 10px 0;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
}
.project_preview{
    width: 245px;
    height: 210px;
    background: #fff9e5;
    margin: 0 auto;
    border-radius: 10px;
    margin-top: 8px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}
.project_preview img{
    width: 100%;
}
.project_name {
    font-size: 20px;
    font-weight: 800;
    text-align: center;
    padding-top: 14px;
    padding-bottom: 9px;
    color: #393939;
}


.resume_layout{
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-top: 120px;
    margin-bottom:150px
}
.resume_container{
    width: 300px;
    background: white;
    border-radius: 10px;
    padding: 10px 0;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
}
.resume_profile{
    width: 200px;
    height: 200px;
    background: #d4d4d4;
    margin: 0 auto;
    border-radius: 100px;
    margin-top: 8px;
    overflow:hidden
}
.resume_profile img{
    width: 100%;
    height: 100%;
}
.resume_name{
    font-size: 20px;
    font-weight: 800;
    text-align: center;
    padding-top: 14px;
    padding-bottom: 9px;
    color: #393939;
}
.resume_layout_right{
    width: 30%;
}
.resume_txt{
    font-size: 40px;
    font-weight: 900;
    color: #1d1d1d;
}
.resume_layout_right button{
    padding: 10px 25px;
    border: none;
    background: #FFB11A;
    border-radius: 7px;
    font-weight: 700;
    font-size: 13px;
    margin-top: 20px;
                font-family: 'Open Sans', sans-serif;
}

        </style>
    </head>
    <body>
            <?php
            require './elements/header.php';
            ?>

<div class="main">
            <div class="map_bg">
                <img src="./assets/map.svg">
            </div>
            <div class="tagline">India's Largest Hackathon Community</div>
            <div class="sub_title">HackerEarth enables organizations to get in front of 7.6 million qualified developers,
                or engage developers internally, with minimal bandwidth drain.</div>
            <button class="join">Join us</button>


            <div class="analytics">
                <div class="analytics_content">
                    <div class="analytics_no">#1</div>
                    <div class="analytics_txt">Best platform for organising and participating hackathons</div>
                </div>
                <div class="analytics_content">
                    <div class="analytics_no">₹0</div>
                    <div class="analytics_txt">Host your hackathons free of cost on hackathon</div>
                </div>
                <div class="analytics_content">
                    <div class="analytics_no">>300K</div>
                    <div class="details">Aim to connect developer worldwide on single platform</div>
                </div>
            </div>

            <div class="title">Hackathon for you</div>


            <div class="hackathon_layout">
                <div class="hackathon_container">
                    <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
                    <div class="theme">Theme</div>
                    <div class="s_line"><div class="theme_box">AI/ML</div></div>
                    <div class="t_line">
                        <div class="members">
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="participants">+500 participants</div>
                        </div>
                        <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
                    </div>
                    <div class="fo_line">
                        <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
                        <div class="apply"><button>Apply Now</button></div>
                    </div>
                </div>
                <div class="hackathon_container">
                    <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
                    <div class="theme">Theme</div>
                    <div class="s_line"><div class="theme_box">AI/ML</div></div>
                    <div class="t_line">
                        <div class="members">
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="participants">+500 participants</div>
                        </div>
                        <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
                    </div>
                    <div class="fo_line">
                        <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
                        <div class="apply"><button>Apply Now</button></div>
                    </div>
                </div>
                <div class="hackathon_container">
                    <div class="f_line"><div class="name">HackBIOS</div><div class="day">10 days left</div></div>
                    <div class="theme">Theme</div>
                    <div class="s_line"><div class="theme_box">AI/ML</div></div>
                    <div class="t_line">
                        <div class="members">
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="profile"></div>
                            <div class="participants">+500 participants</div>
                        </div>
                        <div class="social_links"><div class="web_link"></div><div class="web_link"></div><div class="web_link"></div></div>
                    </div>
                    <div class="fo_line">
                        <div class="highlight"><div class="tag">Offline</div><div class="tag">Starts 15/04/2023</div></div>
                        <div class="apply"><button>Apply Now</button></div>
                    </div>
                </div>
               
            </div>

            <div class="project_layout">
                <div class="project_layout_left">
                    <div class="project_txt">
                        Showcase your projects on bytebox
                    </div>
                    <button>Add Project</button>
                </div>
                <div class="project_layout_right">
                    <div class="project_container">
                        <div class="project_preview"><img src="./assets/project.png"></div>
                        <div class="project_name">Your project name</div>
                    </div>
                </div>
            </div>


            <div class="resume_layout">
                <div class="resume_layout_left">
                    <div class="resume_container">
                        <div class="resume_profile"><img src="./assets/profile.webp"></div>
                        <div class="resume_name">My name</div>
                    </div>
                </div>
                <div class="resume_layout_right">
                    <div class="resume_txt">
                        Build your digital resume on bytebox
                    </div>
                    <button>Create your resume</button>
                </div>
            </div>



        </div>


            <?php
            require './elements/footer.php';
            ?>
    </body>
</html>