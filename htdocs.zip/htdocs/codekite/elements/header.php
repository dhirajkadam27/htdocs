<div class="nav">
    <div class="nav_left">
        <div class="logo">
            <img src="./assets/logo.svg">
        </div>
        <a href="./index.php" id="nav_links" class="nav_links">Home</a>
        <a href="./hackathon.php" class="nav_links">Hackathon</a>
        <a href="./host.html" class="nav_links">Host a hackathon</a>
    </div>
    <div class="nav_right"><button>Login</button></div>
    <div class="nav_right_restrict"><button><i class="fa-regular fa-face-smile-wink"></i><div class="nav_right_restrict_txt">Dhiraj</div> </button>
    <div class="menu">
        <div class="menu_links"><i class="fa-regular fa-face-smile"></i>My Profile</div>
        <div class="menu_links"><i class="fa-brands fa-wpexplorer"></i>My Hackathon</div>
        <div class="menu_links"><i class="fa-regular fa-file"></i>My Resume</div>
        <div class="menu_links"><i class="fa-regular fa-clipboard"></i>My Project</div>
        <div class="menu_links_1"><i class="fa-solid fa-chart-line"></i>Organizer Panel</div>
        <div class="menu_links"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</div>
    </div>
    </div>
</div>