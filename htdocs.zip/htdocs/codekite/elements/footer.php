     <div class="footer">
        <div class="footer_box">
            <div class="footer_title">Codekite</div>
            <a href="#" class="footer_links">About</a>
            <a href="#" class="footer_links">Careers</a>
            <a href="#" class="footer_links">Contact</a>
            <a href="#" class="footer_links">Help</a>
        </div>
        <div class="footer_box">
            <div class="footer_title">Hackathons</div>
            <a href="#" class="footer_links">Browse hackathons</a>
            <a href="#" class="footer_links">Explore Projects</a>
            <a href="#" class="footer_links">Host a hackathon</a>
            <a href="#" class="footer_links">Hackathon guide</a>
        </div>
        <div class="footer_box">
            <div class="footer_title">Portfolio</div>
            <a href="#" class="footer_links">Your Project</a>
            <a href="#" class="footer_links">Your Hackathon</a>
            <a href="#" class="footer_links">Setting</a>
        </div>
        <div class="footer_box">
            <div class="footer_title">Connect</div>
            <a href="#" class="footer_links"><i class="fa-brands fa-twitter"></i>Twitter</a>
            <a href="#" class="footer_links"><i class="fa-brands fa-discord"></i>Discord</a>
            <a href="#" class="footer_links"><i class="fa-brands fa-facebook"></i>Facebook</a>
            <a href="#" class="footer_links"><i class="fa-brands fa-youtube"></i>Youtube</a>
        </div>
    </div>
    <div class="cc">© 2023 Codekite, Inc. All rights reserved.</div>
    