<html>
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style>
            body{
                margin: 0;
                padding: 0;
                font-family: 'Open Sans', sans-serif;
                background: #f0f5f5;
            }
            .nav {
    width: 100%;
    height: 80px;
    background: white;
    display: flex;
    justify-content: space-around;
    align-items: center;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    position: sticky;
    top: 0;
    z-index: 10;
}
.logo img{
    height: 60px;
}
 .steps{
    display: flex;
    width: 30%;
    align-items: center;
    justify-content: center;
    margin: 10px auto;
    margin-top:30px
 }
 .step{
    width: 30px;
    height: 30px;
    background: #c7c7c7;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 100px;
    font-size: 15px;
    font-weight: 600;
    color:#686868;
    border:2px solid #313131
 }
 #step{
    background: #1357BD;
    color: white;
 }
 .line{
    width: 20px;
    height: 2px;
 }
 .title{
    width: 30%;
    font-size: 20px;
    font-weight: 900;
    margin: 10px auto;
    color: #131313;
    margin-top: 35px;
 }
.form{
    width: 24%;
    background: white;
    margin: 10px auto;
    margin-top: 20px;
    padding: 3%;
    padding: 3%;    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    border-radius: 10px;
}
.label{    font-size: 15px;
    font-weight: 400;
    color: #707070;
    margin-bottom: 10px;
}
.form input{
    width: 100%;
    height: 40px;
    border: 1px solid #bfbfbf;
    border-radius: 5px;
    background: #f2f2f2;
    margin-bottom: 20px;
}
.form button{
    width: 100%;
    height: 40px;
    font-size: 15px;
    font-weight: 700;
    border: none;
    border-radius: 5px;
    background: #1357BD;
    color: white;
    margin-top: 10px;
}
        </style>
    </head>
    <body>
    <div class="nav">
        <div class="logo">
            <img src="../assets/logo.svg">
        </div>
</div>

<div class="steps"><div class="step" id="step"></div><div class="line"></div><div class="step"></div><div class="line"></div><div class="step"></div></div>

<div class="title">Pick a username and password</div>

<div class="form">
    <form action="get">
        <div class="label">Email Id</div>
        <input type="text">
        <div class="label">Username</div>
        <input type="text">
        <div class="label">Password</div>
        <input type="text">
        <button>Login</button>
    </form>
</div>
    </body>
</html>