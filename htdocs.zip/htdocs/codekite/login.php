<html>
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style>
            body{
                margin: 0;
                padding: 0;
                font-family: 'Open Sans', sans-serif;
                background: #f0f5f5;
            }
            .nav {
    width: 100%;
    height: 80px;
    background: white;
    display: flex;
    justify-content: space-around;
    align-items: center;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    position: sticky;
    top: 0;
    z-index: 10;
}
.logo img{
    height: 60px;
}
 
.google{
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top:60px
}
.google button {
    width: 30%;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 40px;
    border: none;
    background: #1e1e1e;
    color: white;
    font-size: 15px;
    font-weight: 500;
    border-radius: 5px;
    font-family: 'Open Sans', sans-serif;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
}
.google_txt{
    margin-left:10px
}
.or{
    width: 30%;
    margin: 10px auto;
    display: block;
    text-align: center;
    margin-top:30px
}
.or_line{
    width: 100%;
    height: 1px;
    background: #c7c7c7;
}
.or_txt{
    margin:0 auto;
    margin-top: -13px;
    background: #f0f5f5;
    width: 40px;
}
.form{
    width: 24%;
    background: white;
    margin: 10px auto;
    margin-top: 20px;
    padding: 3%;    box-shadow: rgba(0, 0, 0, 0.08) 0px 1px 4px 0px;
    border-radius: 10px;
}
.label{    font-size: 15px;
    font-weight: 400;
    color: #707070;
    margin-bottom: 10px;
}
.form input{
    width: 100%;
    height: 40px;
    border: 1px solid #bfbfbf;
    border-radius: 5px;
    background: #f2f2f2;
    margin-bottom: 20px;
}
.form button{
    width: 100%;
    height: 40px;
    font-size: 15px;
    font-weight: 700;
    border: none;
    border-radius: 5px;
    background: #1357BD;
    color: white;
    margin-top: 10px;
}
        </style>
    </head>
    <body>
    <div class="nav">
        <div class="logo">
            <img src="./assets/logo.svg">
        </div>
</div>

<div class="google">
    <button><i class="fa-brands fa-google"></i><div class="google_txt">Sign in with Google</div></button>
</div>

<div class="or"><div class="or_line"></div><div class="or_txt">or</div></div>

<div class="form">
    <form action="get">
        <div class="label">Username or email</div>
        <input type="text">
        <div class="label">Password</div>
        <input type="text">
        <button>Login</button>
    </form>
</div>
    </body>
</html>