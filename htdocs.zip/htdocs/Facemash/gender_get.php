<?php
require "./config.php";

$sql = "UPDATE `ty_cse` SET `gender`=0 WHERE `Seat_No` = ".$_GET['Seat']."";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();

?>