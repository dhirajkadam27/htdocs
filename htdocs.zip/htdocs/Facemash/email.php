<?php

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://me.dypgroup.edu.in/populateAllforStudentPost.json?q=aishwaryakamat03@gmail.com');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
    ]);
    curl_setopt($ch, CURLOPT_COOKIE, 'JSESSIONID=39480C44D95F1B98C52181C526DCC7B5');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    
    $response = curl_exec($ch);
     
    echo $response;


?>
