<?php
require "./config.php";
$id=$_GET['id'];
$sql = "SELECT * FROM `fy` WHERE sr=$id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    if($row['UG_Branch']=="Mechanical Engineering"){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://me.dypgroup.edu.in/populateAllforStudentPost.json?q='.$row['Email']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
    ]);
    curl_setopt($ch, CURLOPT_COOKIE, 'JSESSIONID=51CED3B045A2B2F46F5AAA3B7B0521F4');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    
    $response = curl_exec($ch);
     
    $json = json_decode($response, true);
    if(isset($json[0]['imageUrl'])){

            
    
        $studid = str_replace("getStudentProfileImageById.json?id=","",$json[0]['imageUrl']);
        $ch = curl_init();
    
        // set URL and other appropriate options
        curl_setopt($ch, CURLOPT_URL, "http://me.dypgroup.edu.in/api/getStudentProfileImageById.htm?id=".$studid);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_HEADER, 0);
        
        // grab URL and pass it to the browser
        $img = curl_exec($ch);
        
        // close cURL resource, and free up system resources
        curl_close($ch);
    
    
        $contact = $json[0]['contactNo'];
    
        $div = explode(',', $json[0]['Desc']);
        if( count($div) > 3 ) {
            $div = $div[3];
        }
    
        $roll = strstr($json[0]['Desc'], " Roll No : "); //gets all text from needle on
        $roll = strstr($roll, " ) ", true); //
        $roll = str_replace(' Roll No : ', '', $roll);
    
        $dept = explode(',', $json[0]['Desc']);
        if( count($dept) > 3 ) {
            $dept = $dept[1].','.$dept[2];
        }
    

        
echo '';
$sql = "UPDATE `fy` SET `stud_id`='".$studid."',`img`='".base64_encode($img)."',`division`='".$div."',`roll`='".$roll."',`dept`='".$dept."',`contact`='".$contact."',`gender`='1' WHERE Email='".$row['Email']."'";

if ($conn->query($sql) === TRUE) {
    echo '{"img":"data:image/jpg;charset=utf8;base64,'.base64_encode($img).'","msg":"'.$id.'"}';
} else {
echo "Error updating record: " . $conn->error;
}            


    }else{
        echo '{"img":" ","msg":"No image found"}';
    }
    }
  }
} else {
    echo '{"img":" ","msg":"0 results"}';
}

$conn->close();

?>
