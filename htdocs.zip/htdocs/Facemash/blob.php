<?php
require "./config.php";



    $sql = "SELECT * FROM `s.y`";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
if($row['Seat']==0){





    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://me.dypgroup.edu.in/populateAllforStudentPost.json?q='.$row['Email']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
    ]);
    curl_setopt($ch, CURLOPT_COOKIE, 'JSESSIONID=EB5772B88207BE2C7393F1CC0C9F999D');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    
    $response = curl_exec($ch);
     
    $json = json_decode($response, true);
    if(isset($json[0]['imageUrl'])){
    
    
        $studid = str_replace("getStudentProfileImageById.json?id=","",$json[0]['imageUrl']);
    
    
        
        $ch = curl_init();
    
        // set URL and other appropriate options
        curl_setopt($ch, CURLOPT_URL, "http://me.dypgroup.edu.in/api/getStudentProfileImageById.htm?id=".$studid);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_HEADER, 0);
        
        // grab URL and pass it to the browser
        $img = curl_exec($ch);
        
        // close cURL resource, and free up system resources
        curl_close($ch);
    
    
        $contact = $json[0]['contactNo'];
    
        $div = explode(',', $json[0]['Desc']);
        if( count($div) > 3 ) {
            $div = $div[3];
        }
    
        $roll = strstr($json[0]['Desc'], " Roll No : "); //gets all text from needle on
        $roll = strstr($roll, " ) ", true); //
        $roll = str_replace(' Roll No : ', '', $roll);
    
        $dept = explode(',', $json[0]['Desc']);
        if( count($dept) > 3 ) {
            $dept = $dept[1].','.$dept[2];
        }
    

        
echo '<img id="img_3" src="data:image/jpg;charset=utf8;base64,'.base64_encode($img).'" alt="">';
                


$sql = "UPDATE `s.y` SET `Seat`='".$studid."',`img`='".base64_encode($img)."',`division`='".$div."',`roll`='".$roll."',`dept`='".$dept."',`contact`='".$contact."' WHERE Email=".$row['Email']."";

if ($conn->query($sql) === TRUE) {
echo $row['First'];
} else {
echo "Error updating record: " . $conn->error;
}

    }else{
        $studid =0;
        $div =0;
        $roll =0;
        $dept =0;
    }
                    
}

      }



?>
