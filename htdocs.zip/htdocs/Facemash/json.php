<?php
require "./config.php";

$sql = "SELECT * FROM `ty_cse` WHERE gender=1 AND division!='0'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  echo '[';
  while($row = $result->fetch_assoc()) {
    //   echo '<button class="box">';
    //   echo '<img src="data:image/jpg;charset=utf8;base64,'.$row["img"].'"><br>';
    //   echo '<div>'.$row["division"].'</div><br>';
    //   echo '</button>';

    echo '"'.$row["Email"].'",';
  }
  echo ']';
} else {
  echo "0 results";
}


$conn->close();

?>