<?php
require "./config.php";
require "./new_config.php";

$sql = "SELECT * FROM `fy` WHERE gender=0 AND stud_id!=''";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $sql1 = "INSERT INTO `records`(`name`, `img`) VALUES ('".strstr($row["Name"], ' ', true)."','".$row['img']."')";

    if ($conn1->query($sql1) === TRUE) {
      echo "Record updated successfully";
    } else {
      echo "Error updating record: " . $conn1->error;
    }
    


  }
} 

$conn->close();

?>