<?php
require "./config.php";

$sql = "SELECT * FROM `fy` WHERE gender=0 AND stud_id!=''";
$result = $conn->query($sql);
echo '<style>
              body{
                display: flex;
                flex-wrap: wrap;
              }
              .box{
                display: block;
    text-align: center;
    margin: 30px;
              }
              </style>';
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
      echo '<button onclick="send('.$row["stud_id"].')" class="box">';
      echo '<img src="data:image/jpg;charset=utf8;base64,'.$row["img"].'"><br>';
      echo '<div>'.strstr($row["Name"], ' ', true).'</div><br>';
      // echo '<div>'.$row["Surname"].'</div><br>';
      // echo '<div>'.$row["contact"].'</div><br>';
      echo '</button>';
  }
} else {
  echo "0 results";
}

$conn->close();

?>


<script>
function send(Seat){
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    console.log("done");
  }
  xhttp.open("GET", "./gender_get.php?Seat="+Seat);
  xhttp.send();
}
</script>