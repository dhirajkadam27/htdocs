<?php
require "./config.php";

$sql = "SELECT * FROM `s.y` WHERE Seat <> 0";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  $i=0;
  echo '[';
  while($row = $result->fetch_assoc()) {
    if($row["gender"]==0){
        if($i==0){
            $i++;
        }else{
            echo ",";
        }
        echo '['.$row["Seat"].',"'.$row["img"].'","'.$row["First"].'","'.$row["Surname"].'","'.$row["division"].'","'.$row["roll"].'","'.$row["dept"].'"]';

    }
  }
  echo ']';
} else {
  echo "0 results";
}

$conn->close();

?>